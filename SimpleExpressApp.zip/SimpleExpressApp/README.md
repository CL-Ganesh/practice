# aws-ecs-docker
deploy docker container to a ecs cluster.
